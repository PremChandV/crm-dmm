<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "crm";
    $table = "tbl_sales_team";

    $action = $_POST['action'];

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    /* if('CREATE_TABLE' == $action){
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            user_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            firstname VARCHAR(30) NOT NULL,
            lastname VARCHAR(30) NOT NULL
            )";
        if ($conn->query($sql) === TRUE) {
            echo "success";
        } else {
            echo "error";
        }
        $conn->close();
        return;
    } */

    if('GET_ALL' == $action){
        $dbdata = array();
        // $sql = "SELECT user_id, firstname, lastname FROM $table ORDER BY user_id DESC";
        $sql = "SELECT user_id, firstname, lastname, 
                    job_role, email, password, 
                    gender, extension, mobile, 
                    alter_mobile, birth_date, 
                    join_date, address, city, 
                    country, region, postal_code, 
                    report_to, description FROM $table";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $dbdata[]=$row;
            }
            echo json_encode($dbdata);
        } else {
            echo "error";
        }
        $conn->close();
        return;
    }

    if('ADD_USER' == $action){
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $job = $_POST['job_role'];
        $email = $_POST['email'];
        $pass = $_POST['password'];
        $gender = $_POST['gender'];
        $extension = $_POST['extension'];
        $mobile = $_POST['mobile'];
        $alterMobile = $_POST['alter_mobile'];
        $birthDate = $_POST['birth_date'];
        $joinDate = $_POST['join_date'];
        $address = $_POST['address'];
        $city = $_POST['city'];
        $country = $_POST['country'];
        $region = $_POST['region'];
        $postalCode = $_POST['postal_code'];
        $reportTo = $_POST['report_to'];
        $description = $_POST['description'];
        $sql = "INSERT INTO $table (firstname, lastname, 
                                    job_role, email, password, 
                                    gender, extension, mobile, 
                                    alter_mobile, birth_date, 
                                    join_date, address, city, 
                                    country, region, postal_code, 
                                    report_to, description) 
                                    VALUES('$firstname', '$lastname', 
                                            '$job', '$email', '$pass',
                                            '$gender', '$extension', 
                                            '$mobile','$alterMobile', 
                                            '$birthDate', '$joinDate',
                                            '$address', '$city', '$country',
                                            '$region', '$postalCode', 
                                            '$reportTo', '$description')";
        $result = $conn->query($sql);
        echo 'success';
        return;
    }

    if('UPDATE_USER' == $action){
        $userId = $_POST['user_id'];
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $job = $_POST['job_role'];
        $email = $_POST['email'];
        $pass = $_POST['password'];
        $gender = $_POST['gender'];
        $extension = $_POST['extension'];
        $mobile = $_POST['mobile'];
        $alterMobile = $_POST['alter_mobile'];
        $birthDate = $_POST['birth_date'];
        $joinDate = $_POST['join_date'];
        $address = $_POST['address'];
        $city = $_POST['city'];
        $country = $_POST['country'];
        $region = $_POST['region'];
        $postalCode = $_POST['postal_code'];
        $reportTo = $_POST['report_to'];
        $description = $_POST['description'];
        $sql = "UPDATE $table SET firstname = '$firstname', 
                                    lastname = '$lastname',
                                    job_role = '$job',
                                    email = '$email',
                                    password = '$pass',
                                    gender = '$gender',
                                    extension = '$extension',
                                    mobile = '$mobile',
                                    alter_mobile = '$alterMobile',
                                    birth_date = '$birthDate',
                                    join_date = '$joinDate',
                                    address = '$address',
                                    city = '$city',
                                    country = '$country',
                                    region = '$region',
                                    postal_code = '$postalCode',
                                    report_to = '$reportTo',
                                    description = '$description',
                                WHERE user_id = $userId";
        if ($conn->query($sql) === TRUE) {
            echo "success";
        } else {
            echo "error";
        }
        $conn->close();
        return;
    }

    if('DELETE_USER' == $action){
        $userId = $_POST['user_id'];
        $sql = "DELETE FROM $table WHERE user_id = $userId";
        if ($conn->query($sql) === TRUE) {
            echo "success";
        } else {
            echo "error";
        }
        $conn->close();
        return;
    }
    
?>
